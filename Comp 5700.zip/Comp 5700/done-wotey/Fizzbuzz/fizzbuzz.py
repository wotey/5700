def fizzbuzz(n=None):
    FIZZ_VALUE = "fizz"
    BUZZ_VALUE = "buzz"
    FIZZBUZZ_VALUE = "fizzbuzz"
    ERROR_VALUE = "error"
    LOWER_BOUND = 0
    UPPER_BOUND = 932
    FIZZ_NUMERIC = 3
    BUZZ_NUMERIC = 5
    
    if(n == None):
        return ERROR_VALUE
    if(not(isinstance(n, int))):
        return ERROR_VALUE
    if(n < LOWER_BOUND):
        return ERROR_VALUE
    if(n > UPPER_BOUND):
        return ERROR_VALUE
    
    fizzRemainder = n % FIZZ_NUMERIC
    buzzRamainder = n % BUZZ_NUMERIC
    
    if((buzzRamainder == 0) & (fizzRemainder == 0)):
        return FIZZBUZZ_VALUE
    if(fizzRemainder == 0):
        return FIZZ_VALUE
    if(buzzRamainder == 0):
        return BUZZ_VALUE
    return str(n)
