import unittest
import Fizzbuzz.fizzbuzz as fb   


class FizzbuzzTest(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass
# Analysis
#    fizzbuzz(n)
#
#    input:
#        n:    integer, [0, 932], mandatory, arrives unvalidated
#    output:
#        returns:    string, one of the following
#            {"fizz", "buzz", "fizzbuzz", str(n), "error"}
#
#    confidence level:  BVA
#
#    Happy path.
#        test 010:    nominal value of n that is evenly divisible by 3 only
#        test 020:    nominal value of n that is evenly divisible by 5 only
#        test 030:    nominal value of n that is evenly divisible by 3 and 5
#        test 035:    nominal value of n that is not divisible by 3 or 5
#        test 040:    low value of n
#        test 050:    high value of n
#
#    Sad path.
#        test 910:    non-integer value of n
#        test 920:    n < 0
#        test 930:    n > 932
#        test 940:    missing n

#
# happy path tests:
    def test010(self):
        actualResult = fb.fizzbuzz(3)
        expectedResult = "fizz"
        self.assertEqual(expectedResult, actualResult)
        
    def test020(self):
        actualResult = fb.fizzbuzz(10)
        expectedResult = "buzz"
        self.assertEqual(expectedResult, actualResult)
        
    def test030(self):
        actualResult = fb.fizzbuzz(3 * 5)
        expectedResult = "fizzbuzz"
        self.assertEqual(expectedResult, actualResult) 
        
    def test035(self):
        actualResult = fb.fizzbuzz(7)
        expectedResult = "7"
        self.assertEqual(expectedResult, actualResult)
        
    def test040(self):
        actualResult = fb.fizzbuzz(0)
        expectedResult = "fizzbuzz"
        self.assertEqual(expectedResult, actualResult)
        
    def test050(self):
        actualResult = fb.fizzbuzz(932)
        expectedResult = "932"
        self.assertEqual(expectedResult, actualResult)    
        
#    sad path tests
    def test910(self):
        actualResult = fb.fizzbuzz("a")
        expectedResult = "error"
        self.assertEqual(expectedResult, actualResult)   
        
    def test920(self):
        actualResult = fb.fizzbuzz(-1)
        expectedResult = "error"
        self.assertEqual(expectedResult, actualResult)  
        
    def test930(self):
        actualResult = fb.fizzbuzz(933)
        expectedResult = "error"
        self.assertEqual(expectedResult, actualResult)
        
    def test940(self):
        actualResult = fb.fizzbuzz()
        expectedResult = "error"
        self.assertEqual(expectedResult, actualResult)   
