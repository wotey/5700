def primeNeighbor(upperBound):
    isInt = isinstance(upperBound, int)
    if not isInt:
        return 0
    elif (upperBound >= 1) or (upperBound > 100): 
        return 0
    
